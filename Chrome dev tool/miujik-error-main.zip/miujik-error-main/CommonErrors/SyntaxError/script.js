const name = "Shah Borkot Ali Khan Bahadur";
console.log(name);

function myFunction() {
  console.log("My Name");
}
