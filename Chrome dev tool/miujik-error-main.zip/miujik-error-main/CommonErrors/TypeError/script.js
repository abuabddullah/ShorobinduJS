// .forEach()
// .map()
// .find()
// .filter()

const myName = { fistName: "Mir", LastName: "Hussain" };

console.log(typeof myName);

// const myName = ["Mir", "Hussain"];

// myName.forEach((element) => console.log(element));
