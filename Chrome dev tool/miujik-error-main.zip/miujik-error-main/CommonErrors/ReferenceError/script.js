// const pen = "All Time";
// console.log(pencil);

printName();
